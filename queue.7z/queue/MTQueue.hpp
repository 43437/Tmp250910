#ifndef MT_QUEUE_H__
#define MT_QUEUE_H__

#include "SISOQueue.hpp"
#include <mutex>
#include <thread>

template<typename T>
class MTQueue {
public:
    explicit MTQueue(size_t capacity) 
        : m_objQueue(capacity){
    };

    bool enqueue(const T& item) {
        if (std::thread::id() != m_objThdWriter)
        {
            if (std::this_thread::get_id() == m_objThdWriter)
            {
                return m_objQueue.enqueue(item);
            }
        }
        else
        {
            //lock
            std::lock_guard<std::mutex> lock(m_objWriter);
            return m_objQueue.enqueue(item);
        }
        return false;
    };

    bool dequeue(T& item) {
        if (std::thread::id() != m_objThdReader)
        {
            if (std::this_thread::get_id() == m_objThdReader)
            {
                return m_objQueue.dequeue(item);
            }
        }
        else
        {
            //lock
            std::lock_guard<std::mutex> lock(m_objReader);
            return m_objQueue.dequeue(item);
        }
        return false;
    };

    void setReadOwner(const std::thread::id& id)
    {
        m_objThdReader = id;
    };

    void setWriteOwner(const std::thread::id& id)
    {
        m_objThdWriter = id;
    };

private:
    SISOQueue<T> m_objQueue;
    std::mutex m_objReader;
    std::mutex m_objWriter;

    std::thread::id m_objThdReader;
    std::thread::id m_objThdWriter;
};

#endif