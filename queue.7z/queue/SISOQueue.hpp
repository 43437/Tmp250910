#ifndef SISO_QUEUE_H__
#define SISO_QUEUE_H__

#include <atomic>
#include <vector>

template<typename T>
class SISOQueue {
public:
    explicit SISOQueue(size_t capacity)
        : buffer_(capacity), capacity_(capacity), head_(0), tail_(0) {
    }

    bool enqueue(const T& item) {
        size_t current_tail = tail_.load(std::memory_order_relaxed);
        size_t next_tail = (current_tail + 1) % capacity_;
        if (next_tail == head_.load(std::memory_order_acquire)) { // ����Ƿ���
            return false;
        }
        buffer_[current_tail] = item;
        tail_.store(next_tail, std::memory_order_release); // ����βָ��
        return true;
    }

    bool dequeue(T& item) {
        size_t current_head = head_.load(std::memory_order_relaxed);
        if (current_head == tail_.load(std::memory_order_acquire)) { // ����Ƿ��
            return false;
        }
        item = buffer_[current_head];
        head_.store((current_head + 1) % capacity_, std::memory_order_release); // ����ͷָ��
        return true;
    }

private:
    std::vector<T> buffer_;
    size_t capacity_;
    std::atomic<size_t> head_;
    std::atomic<size_t> tail_;
};

#endif // !MT_QUEUE_H__
